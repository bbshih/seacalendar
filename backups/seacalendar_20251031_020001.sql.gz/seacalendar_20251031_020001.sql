--
-- PostgreSQL database dump
--

\restrict kj7LaT4mYmKAzV3811dLJrdvCvYg4DXHbUYeUj1fgFiB1gGa1KucCtUKm932nHn

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: PollStatus; Type: TYPE; Schema: public; Owner: dev
--

CREATE TYPE public."PollStatus" AS ENUM (
    'DRAFT',
    'VOTING',
    'FINALIZED',
    'CANCELLED',
    'EXPIRED'
);


ALTER TYPE public."PollStatus" OWNER TO dev;

--
-- Name: PollType; Type: TYPE; Schema: public; Owner: dev
--

CREATE TYPE public."PollType" AS ENUM (
    'EVENT',
    'GENERIC'
);


ALTER TYPE public."PollType" OWNER TO dev;

--
-- Name: ReminderStatus; Type: TYPE; Schema: public; Owner: dev
--

CREATE TYPE public."ReminderStatus" AS ENUM (
    'PENDING',
    'SENT',
    'FAILED',
    'CANCELLED'
);


ALTER TYPE public."ReminderStatus" OWNER TO dev;

--
-- Name: ReminderType; Type: TYPE; Schema: public; Owner: dev
--

CREATE TYPE public."ReminderType" AS ENUM (
    'VOTE_REMINDER_3DAY',
    'VOTE_REMINDER_1DAY',
    'EVENT_REMINDER_1WEEK',
    'EVENT_REMINDER_1DAY',
    'EVENT_REMINDER_2HOUR'
);


ALTER TYPE public."ReminderType" OWNER TO dev;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    action text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text NOT NULL,
    "pollId" text,
    "userId" text,
    "ipAddress" text,
    "userAgent" text,
    metadata jsonb,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO dev;

--
-- Name: DiscordToken; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public."DiscordToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "accessToken" text NOT NULL,
    "refreshToken" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DiscordToken" OWNER TO dev;

--
-- Name: EventReminder; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public."EventReminder" (
    id text NOT NULL,
    "pollId" text NOT NULL,
    type public."ReminderType" NOT NULL,
    "scheduledFor" timestamp(3) without time zone NOT NULL,
    "sentAt" timestamp(3) without time zone,
    status public."ReminderStatus" DEFAULT 'PENDING'::public."ReminderStatus" NOT NULL
);


ALTER TABLE public."EventReminder" OWNER TO dev;

--
-- Name: Poll; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public."Poll" (
    id text NOT NULL,
    type public."PollType" DEFAULT 'EVENT'::public."PollType" NOT NULL,
    title text NOT NULL,
    description text,
    "creatorId" text NOT NULL,
    "guildId" text,
    "channelId" text,
    "messageId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "votingDeadline" timestamp(3) without time zone,
    "closedAt" timestamp(3) without time zone,
    status public."PollStatus" DEFAULT 'VOTING'::public."PollStatus" NOT NULL,
    "finalizedOptionId" text,
    "venueId" text
);


ALTER TABLE public."Poll" OWNER TO dev;

--
-- Name: PollInvite; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public."PollInvite" (
    id text NOT NULL,
    "pollId" text NOT NULL,
    "userId" text NOT NULL,
    "invitedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "hasVoted" boolean DEFAULT false NOT NULL,
    "remindersSent" integer DEFAULT 0 NOT NULL,
    "lastReminderAt" timestamp(3) without time zone
);


ALTER TABLE public."PollInvite" OWNER TO dev;

--
-- Name: PollOption; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public."PollOption" (
    id text NOT NULL,
    "pollId" text NOT NULL,
    label text NOT NULL,
    description text,
    "order" integer DEFAULT 0 NOT NULL,
    date timestamp(3) without time zone,
    "timeStart" text,
    "timeEnd" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PollOption" OWNER TO dev;

--
-- Name: PollTemplate; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public."PollTemplate" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "templateData" jsonb NOT NULL,
    "creatorId" text NOT NULL,
    "guildId" text NOT NULL,
    "timesUsed" integer DEFAULT 0 NOT NULL,
    "lastUsedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PollTemplate" OWNER TO dev;

--
-- Name: RateLimitLog; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public."RateLimitLog" (
    id text NOT NULL,
    identifier text NOT NULL,
    endpoint text NOT NULL,
    "requestCount" integer NOT NULL,
    "windowStart" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."RateLimitLog" OWNER TO dev;

--
-- Name: RefreshToken; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public."RefreshToken" (
    id text NOT NULL,
    token text NOT NULL,
    "userId" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    revoked boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."RefreshToken" OWNER TO dev;

--
-- Name: User; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "discordId" text NOT NULL,
    email text,
    phone text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    avatar text,
    discriminator text NOT NULL,
    username text NOT NULL
);


ALTER TABLE public."User" OWNER TO dev;

--
-- Name: UserPreferences; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public."UserPreferences" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "notifyViaDiscordDM" boolean DEFAULT true NOT NULL,
    "notifyViaEmail" boolean DEFAULT false NOT NULL,
    "notifyViaSMS" boolean DEFAULT false NOT NULL,
    "wantVoteReminders" boolean DEFAULT true NOT NULL,
    "wantEventReminders" boolean DEFAULT true NOT NULL,
    "showInStats" boolean DEFAULT true NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."UserPreferences" OWNER TO dev;

--
-- Name: Venue; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public."Venue" (
    id text NOT NULL,
    name text NOT NULL,
    address text,
    "googleMapsUrl" text,
    notes text,
    "guildId" text NOT NULL,
    "addedById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Venue" OWNER TO dev;

--
-- Name: Vote; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public."Vote" (
    id text NOT NULL,
    "pollId" text NOT NULL,
    "voterId" text NOT NULL,
    "availableOptionIds" text[],
    "maybeOptionIds" text[],
    notes text,
    "votedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Vote" OWNER TO dev;

--
-- Name: _VoteAvailableOptions; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public."_VoteAvailableOptions" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_VoteAvailableOptions" OWNER TO dev;

--
-- Name: _VoteMaybeOptions; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public."_VoteMaybeOptions" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_VoteMaybeOptions" OWNER TO dev;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO dev;

--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public."AuditLog" (id, action, "entityType", "entityId", "pollId", "userId", "ipAddress", "userAgent", metadata, "timestamp") FROM stdin;
\.


--
-- Data for Name: DiscordToken; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public."DiscordToken" (id, "userId", "accessToken", "refreshToken", "expiresAt", "createdAt", "updatedAt") FROM stdin;
4627ca8e-da13-4b3d-8791-a9193bc1aa03	6c747369-8134-4a14-8f5c-9af20f147050	MTQzMzEzNDAyNzY2NTMwOTc5Mg.taCXXWIPZNEJPMb2B64820VXh7sMMK	m9DrbFLeNoyZ5AasHwzWVWc3n0OTTR	2025-11-06 17:02:21.471	2025-10-30 05:38:37.779	2025-10-30 17:02:21.472
\.


--
-- Data for Name: EventReminder; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public."EventReminder" (id, "pollId", type, "scheduledFor", "sentAt", status) FROM stdin;
\.


--
-- Data for Name: Poll; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public."Poll" (id, type, title, description, "creatorId", "guildId", "channelId", "messageId", "createdAt", "votingDeadline", "closedAt", status, "finalizedOptionId", "venueId") FROM stdin;
31d0df35-7e9b-408e-9451-afdf05c7ddd2	EVENT	Test Boys Night		6c747369-8134-4a14-8f5c-9af20f147050	904952731045871616	910774939303444491	\N	2025-10-30 00:19:13.89	2025-11-13 00:19:13.863	\N	VOTING	\N	\N
\.


--
-- Data for Name: PollInvite; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public."PollInvite" (id, "pollId", "userId", "invitedAt", "hasVoted", "remindersSent", "lastReminderAt") FROM stdin;
\.


--
-- Data for Name: PollOption; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public."PollOption" (id, "pollId", label, description, "order", date, "timeStart", "timeEnd", "createdAt") FROM stdin;
6af5dff2-af63-4128-bf97-169a84e879fd	31d0df35-7e9b-408e-9451-afdf05c7ddd2	Sat, Dec 6, 2025	\N	0	2025-12-06 00:00:00	\N	\N	2025-10-30 00:19:13.89
74c8eb1b-2ae6-4934-ad24-71e01981dd19	31d0df35-7e9b-408e-9451-afdf05c7ddd2	Sun, Dec 7, 2025	\N	1	2025-12-07 00:00:00	\N	\N	2025-10-30 00:19:13.89
076fb910-70f0-47c0-8955-42c81456ac22	31d0df35-7e9b-408e-9451-afdf05c7ddd2	Sat, Dec 13, 2025	\N	2	2025-12-13 00:00:00	\N	\N	2025-10-30 00:19:13.89
df33de08-8a39-4b73-a1ea-f5c82e5a7706	31d0df35-7e9b-408e-9451-afdf05c7ddd2	Sun, Dec 14, 2025	\N	3	2025-12-14 00:00:00	\N	\N	2025-10-30 00:19:13.89
49c0dad2-df9f-40ef-970a-9a0988e50b11	31d0df35-7e9b-408e-9451-afdf05c7ddd2	Sat, Dec 20, 2025	\N	4	2025-12-20 00:00:00	\N	\N	2025-10-30 00:19:13.89
a1be2063-cd10-40d3-a550-4906665a9cea	31d0df35-7e9b-408e-9451-afdf05c7ddd2	Sun, Dec 21, 2025	\N	5	2025-12-21 00:00:00	\N	\N	2025-10-30 00:19:13.89
1d1c53c0-9fe3-44ce-b6f0-86eb0db85225	31d0df35-7e9b-408e-9451-afdf05c7ddd2	Sat, Dec 27, 2025	\N	6	2025-12-27 00:00:00	\N	\N	2025-10-30 00:19:13.89
f09112a3-ac0e-437e-9626-cbf9e9695bc7	31d0df35-7e9b-408e-9451-afdf05c7ddd2	Sun, Dec 28, 2025	\N	7	2025-12-28 00:00:00	\N	\N	2025-10-30 00:19:13.89
\.


--
-- Data for Name: PollTemplate; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public."PollTemplate" (id, name, description, "templateData", "creatorId", "guildId", "timesUsed", "lastUsedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: RateLimitLog; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public."RateLimitLog" (id, identifier, endpoint, "requestCount", "windowStart") FROM stdin;
\.


--
-- Data for Name: RefreshToken; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public."RefreshToken" (id, token, "userId", "expiresAt", revoked, "createdAt") FROM stdin;
3477e29d-7dcf-416f-b0a1-b0cec71f6659	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2Yzc0NzM2OS04MTM0LTRhMTQtOGY1Yy05YWYyMGYxNDcwNTAiLCJ0eXBlIjoicmVmcmVzaCIsImlhdCI6MTc2MTgwNjMyMywiZXhwIjoxNzYyNDExMTIzfQ.gPH6k-nqHkh27aYK5AvWol0f_n1BV2sjvt4ZwzNwPzg	6c747369-8134-4a14-8f5c-9af20f147050	2025-11-06 06:38:43.514	f	2025-10-30 06:38:43.515
1740502c-7dc5-40b8-aaff-cd0eb80d9df2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2Yzc0NzM2OS04MTM0LTRhMTQtOGY1Yy05YWYyMGYxNDcwNTAiLCJ0eXBlIjoicmVmcmVzaCIsImlhdCI6MTc2MTgwMjcxNywiZXhwIjoxNzYyNDA3NTE3fQ.enigEB4albjvA6kf-6ruHa1iaqwTnhYlJO6wjwGxm_s	6c747369-8134-4a14-8f5c-9af20f147050	2025-11-06 05:38:37.789	t	2025-10-30 05:38:37.79
927432fd-2b47-4b55-b935-35fe313bb889	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2Yzc0NzM2OS04MTM0LTRhMTQtOGY1Yy05YWYyMGYxNDcwNTAiLCJ0eXBlIjoicmVmcmVzaCIsImlhdCI6MTc2MTg0NzUzMCwiZXhwIjoxNzYyNDUyMzMwfQ.4JILyyTvzOGaSdKsfHWaFNSVDhfaeR4JToOuuv8lqiM	6c747369-8134-4a14-8f5c-9af20f147050	2025-11-06 18:05:30.551	f	2025-10-30 18:05:30.552
1e32ba28-8b39-4120-9f67-f82a1ae2a3c5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2Yzc0NzM2OS04MTM0LTRhMTQtOGY1Yy05YWYyMGYxNDcwNTAiLCJ0eXBlIjoicmVmcmVzaCIsImlhdCI6MTc2MTg0Mzc0MSwiZXhwIjoxNzYyNDQ4NTQxfQ.i9yXGQLQNC1rY0X4tuGRie1jn4Sd8GxZiLwhwxS-dB0	6c747369-8134-4a14-8f5c-9af20f147050	2025-11-06 17:02:21.476	t	2025-10-30 17:02:21.477
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public."User" (id, "discordId", email, phone, "createdAt", "updatedAt", avatar, discriminator, username) FROM stdin;
6c747369-8134-4a14-8f5c-9af20f147050	106172148699131904	bbshih@gmail.com	\N	2025-10-30 00:03:14.166	2025-10-30 17:02:21.468	165b88192bf07daae45401d05d39673f	0	billyeatstofu
\.


--
-- Data for Name: UserPreferences; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public."UserPreferences" (id, "userId", "notifyViaDiscordDM", "notifyViaEmail", "notifyViaSMS", "wantVoteReminders", "wantEventReminders", "showInStats", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Venue; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public."Venue" (id, name, address, "googleMapsUrl", notes, "guildId", "addedById", "createdAt") FROM stdin;
\.


--
-- Data for Name: Vote; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public."Vote" (id, "pollId", "voterId", "availableOptionIds", "maybeOptionIds", notes, "votedAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: _VoteAvailableOptions; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public."_VoteAvailableOptions" ("A", "B") FROM stdin;
\.


--
-- Data for Name: _VoteMaybeOptions; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public."_VoteMaybeOptions" ("A", "B") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
a1947e6b-24a8-42f1-a2a5-7064611fd13b	51aa216e84e2e815f459d1b1eb400e4ed0568a5f1d4fcd52932d99a934ae605c	2025-10-29 03:59:09.808265+00	20251029035909_init	\N	\N	2025-10-29 03:59:09.6508+00	1
dc9e27f5-02c3-4aaa-b009-2f7178d97a01	6e8c3ab961fbd2107c36b78f292a0bfd935acc9e211a6d21d9b95add7ea7fa7a	2025-10-29 17:52:31.391235+00	20251029175231_fix_user_schema	\N	\N	2025-10-29 17:52:31.354145+00	1
\.


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: DiscordToken DiscordToken_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."DiscordToken"
    ADD CONSTRAINT "DiscordToken_pkey" PRIMARY KEY (id);


--
-- Name: EventReminder EventReminder_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."EventReminder"
    ADD CONSTRAINT "EventReminder_pkey" PRIMARY KEY (id);


--
-- Name: PollInvite PollInvite_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."PollInvite"
    ADD CONSTRAINT "PollInvite_pkey" PRIMARY KEY (id);


--
-- Name: PollOption PollOption_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."PollOption"
    ADD CONSTRAINT "PollOption_pkey" PRIMARY KEY (id);


--
-- Name: PollTemplate PollTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."PollTemplate"
    ADD CONSTRAINT "PollTemplate_pkey" PRIMARY KEY (id);


--
-- Name: Poll Poll_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."Poll"
    ADD CONSTRAINT "Poll_pkey" PRIMARY KEY (id);


--
-- Name: RateLimitLog RateLimitLog_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."RateLimitLog"
    ADD CONSTRAINT "RateLimitLog_pkey" PRIMARY KEY (id);


--
-- Name: RefreshToken RefreshToken_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_pkey" PRIMARY KEY (id);


--
-- Name: UserPreferences UserPreferences_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."UserPreferences"
    ADD CONSTRAINT "UserPreferences_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Venue Venue_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."Venue"
    ADD CONSTRAINT "Venue_pkey" PRIMARY KEY (id);


--
-- Name: Vote Vote_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."Vote"
    ADD CONSTRAINT "Vote_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AuditLog_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "AuditLog_entityType_entityId_idx" ON public."AuditLog" USING btree ("entityType", "entityId");


--
-- Name: AuditLog_timestamp_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "AuditLog_timestamp_idx" ON public."AuditLog" USING btree ("timestamp");


--
-- Name: AuditLog_userId_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "AuditLog_userId_idx" ON public."AuditLog" USING btree ("userId");


--
-- Name: DiscordToken_userId_key; Type: INDEX; Schema: public; Owner: dev
--

CREATE UNIQUE INDEX "DiscordToken_userId_key" ON public."DiscordToken" USING btree ("userId");


--
-- Name: EventReminder_status_scheduledFor_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "EventReminder_status_scheduledFor_idx" ON public."EventReminder" USING btree (status, "scheduledFor");


--
-- Name: PollInvite_pollId_hasVoted_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "PollInvite_pollId_hasVoted_idx" ON public."PollInvite" USING btree ("pollId", "hasVoted");


--
-- Name: PollInvite_pollId_userId_key; Type: INDEX; Schema: public; Owner: dev
--

CREATE UNIQUE INDEX "PollInvite_pollId_userId_key" ON public."PollInvite" USING btree ("pollId", "userId");


--
-- Name: PollInvite_userId_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "PollInvite_userId_idx" ON public."PollInvite" USING btree ("userId");


--
-- Name: PollOption_pollId_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "PollOption_pollId_idx" ON public."PollOption" USING btree ("pollId");


--
-- Name: PollTemplate_guildId_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "PollTemplate_guildId_idx" ON public."PollTemplate" USING btree ("guildId");


--
-- Name: PollTemplate_guildId_name_key; Type: INDEX; Schema: public; Owner: dev
--

CREATE UNIQUE INDEX "PollTemplate_guildId_name_key" ON public."PollTemplate" USING btree ("guildId", name);


--
-- Name: Poll_creatorId_status_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "Poll_creatorId_status_idx" ON public."Poll" USING btree ("creatorId", status);


--
-- Name: Poll_guildId_status_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "Poll_guildId_status_idx" ON public."Poll" USING btree ("guildId", status);


--
-- Name: Poll_messageId_key; Type: INDEX; Schema: public; Owner: dev
--

CREATE UNIQUE INDEX "Poll_messageId_key" ON public."Poll" USING btree ("messageId");


--
-- Name: Poll_votingDeadline_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "Poll_votingDeadline_idx" ON public."Poll" USING btree ("votingDeadline");


--
-- Name: RateLimitLog_identifier_endpoint_windowStart_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "RateLimitLog_identifier_endpoint_windowStart_idx" ON public."RateLimitLog" USING btree (identifier, endpoint, "windowStart");


--
-- Name: RefreshToken_token_key; Type: INDEX; Schema: public; Owner: dev
--

CREATE UNIQUE INDEX "RefreshToken_token_key" ON public."RefreshToken" USING btree (token);


--
-- Name: RefreshToken_token_revoked_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "RefreshToken_token_revoked_idx" ON public."RefreshToken" USING btree (token, revoked);


--
-- Name: RefreshToken_userId_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "RefreshToken_userId_idx" ON public."RefreshToken" USING btree ("userId");


--
-- Name: UserPreferences_userId_key; Type: INDEX; Schema: public; Owner: dev
--

CREATE UNIQUE INDEX "UserPreferences_userId_key" ON public."UserPreferences" USING btree ("userId");


--
-- Name: User_discordId_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "User_discordId_idx" ON public."User" USING btree ("discordId");


--
-- Name: User_discordId_key; Type: INDEX; Schema: public; Owner: dev
--

CREATE UNIQUE INDEX "User_discordId_key" ON public."User" USING btree ("discordId");


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: dev
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_phone_key; Type: INDEX; Schema: public; Owner: dev
--

CREATE UNIQUE INDEX "User_phone_key" ON public."User" USING btree (phone);


--
-- Name: Venue_guildId_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "Venue_guildId_idx" ON public."Venue" USING btree ("guildId");


--
-- Name: Venue_name_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "Venue_name_idx" ON public."Venue" USING btree (name);


--
-- Name: Vote_pollId_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "Vote_pollId_idx" ON public."Vote" USING btree ("pollId");


--
-- Name: Vote_pollId_voterId_key; Type: INDEX; Schema: public; Owner: dev
--

CREATE UNIQUE INDEX "Vote_pollId_voterId_key" ON public."Vote" USING btree ("pollId", "voterId");


--
-- Name: Vote_voterId_idx; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "Vote_voterId_idx" ON public."Vote" USING btree ("voterId");


--
-- Name: _VoteAvailableOptions_AB_unique; Type: INDEX; Schema: public; Owner: dev
--

CREATE UNIQUE INDEX "_VoteAvailableOptions_AB_unique" ON public."_VoteAvailableOptions" USING btree ("A", "B");


--
-- Name: _VoteAvailableOptions_B_index; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "_VoteAvailableOptions_B_index" ON public."_VoteAvailableOptions" USING btree ("B");


--
-- Name: _VoteMaybeOptions_AB_unique; Type: INDEX; Schema: public; Owner: dev
--

CREATE UNIQUE INDEX "_VoteMaybeOptions_AB_unique" ON public."_VoteMaybeOptions" USING btree ("A", "B");


--
-- Name: _VoteMaybeOptions_B_index; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "_VoteMaybeOptions_B_index" ON public."_VoteMaybeOptions" USING btree ("B");


--
-- Name: AuditLog AuditLog_pollId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pollId_fkey" FOREIGN KEY ("pollId") REFERENCES public."Poll"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: DiscordToken DiscordToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."DiscordToken"
    ADD CONSTRAINT "DiscordToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EventReminder EventReminder_pollId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."EventReminder"
    ADD CONSTRAINT "EventReminder_pollId_fkey" FOREIGN KEY ("pollId") REFERENCES public."Poll"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PollInvite PollInvite_pollId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."PollInvite"
    ADD CONSTRAINT "PollInvite_pollId_fkey" FOREIGN KEY ("pollId") REFERENCES public."Poll"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PollInvite PollInvite_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."PollInvite"
    ADD CONSTRAINT "PollInvite_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PollOption PollOption_pollId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."PollOption"
    ADD CONSTRAINT "PollOption_pollId_fkey" FOREIGN KEY ("pollId") REFERENCES public."Poll"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Poll Poll_creatorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."Poll"
    ADD CONSTRAINT "Poll_creatorId_fkey" FOREIGN KEY ("creatorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Poll Poll_venueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."Poll"
    ADD CONSTRAINT "Poll_venueId_fkey" FOREIGN KEY ("venueId") REFERENCES public."Venue"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: RefreshToken RefreshToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserPreferences UserPreferences_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."UserPreferences"
    ADD CONSTRAINT "UserPreferences_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Vote Vote_pollId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."Vote"
    ADD CONSTRAINT "Vote_pollId_fkey" FOREIGN KEY ("pollId") REFERENCES public."Poll"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Vote Vote_voterId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."Vote"
    ADD CONSTRAINT "Vote_voterId_fkey" FOREIGN KEY ("voterId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: _VoteAvailableOptions _VoteAvailableOptions_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."_VoteAvailableOptions"
    ADD CONSTRAINT "_VoteAvailableOptions_A_fkey" FOREIGN KEY ("A") REFERENCES public."PollOption"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _VoteAvailableOptions _VoteAvailableOptions_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."_VoteAvailableOptions"
    ADD CONSTRAINT "_VoteAvailableOptions_B_fkey" FOREIGN KEY ("B") REFERENCES public."Vote"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _VoteMaybeOptions _VoteMaybeOptions_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."_VoteMaybeOptions"
    ADD CONSTRAINT "_VoteMaybeOptions_A_fkey" FOREIGN KEY ("A") REFERENCES public."PollOption"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _VoteMaybeOptions _VoteMaybeOptions_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public."_VoteMaybeOptions"
    ADD CONSTRAINT "_VoteMaybeOptions_B_fkey" FOREIGN KEY ("B") REFERENCES public."Vote"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict kj7LaT4mYmKAzV3811dLJrdvCvYg4DXHbUYeUj1fgFiB1gGa1KucCtUKm932nHn

